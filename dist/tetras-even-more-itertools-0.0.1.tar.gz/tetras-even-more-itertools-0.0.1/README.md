# even-more-itertools
 My personal collection of itertools-based "convenience" functions.
