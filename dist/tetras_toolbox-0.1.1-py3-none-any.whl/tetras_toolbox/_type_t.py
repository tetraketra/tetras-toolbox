class T:
    """This is not a real class! Only exists for type `T` annotations."""
