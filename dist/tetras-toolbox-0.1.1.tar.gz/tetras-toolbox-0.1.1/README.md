# even-more-itertools
 My personal collection of often-itertools-based "convenience" functions.
